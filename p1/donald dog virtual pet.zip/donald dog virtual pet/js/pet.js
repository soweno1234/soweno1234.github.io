let interest = 0;
let belly = 0;
let happiness = 0;

function feedPet() {
    console.log("this will increase the belly variable");
    //this function will make the pet less hungry by giving it food. as the belly gets more emtpy, so will the happiness
}

function playPet() {
    console.log("this will increase the interest level");
    /*this function will make the player play games with the pet, and it will increase the pet's interest level. 
    A combination of this and the hunger level both influence the overall happiness.*/
}